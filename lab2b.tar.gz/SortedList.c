//NAME: Connor Borden
//EMAIL: connorbo97@g.ucla.edu
//ID: 004603469
#define _GNU_SOURCE

#include <time.h>
#include <pthread.h>
#include <string.h>
#include <getopt.h>
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

#include "SortedList.h"


extern int mutexFlag;
extern int spinFlag;
extern int spinLock;
extern int numLists;

void SortedList_insert(SortedList_t *list, SortedListElement_t *element)
{
	if(list == NULL || element == NULL)
	{
		return;
	}
	SortedListElement_t *temp = list->next; //not the header
	
	//else if(mutexFlag)
	//	pthread_mutex_lock(&lock);
	
	while(temp != list)
	{
		if(strcmp(element->key, temp->key) <= 0)
		{
			break;
		}
		
		temp = temp->next;
	}
	
	if(opt_yield & INSERT_YIELD)
	{
		pthread_yield();
	}
	element->next = temp;
	element->prev = temp->prev;
	temp->prev->next = element;
	temp->prev = element;

}

int SortedList_delete(SortedListElement_t *element)
{
	if(element == NULL)
	{
		return 1;
	}
	if(element->next->prev == element->prev->next)
	{
		if(opt_yield & DELETE_YIELD)
			sched_yield();
		
		element->prev->next = element->next;
		element->next->prev = element->prev;
		element->next = NULL;
		element->prev = NULL;
		return 0;
	}
	else
	{
		return 1; //means corrupted pointers
	}
}

SortedListElement_t *SortedList_lookup(SortedList_t *list, const char *key)
{
	
	if(list == NULL || key == NULL)
	{	
		return NULL;
	}
	SortedListElement_t *temp = list->next; //first non head
	while(temp != list )
	{
		if(temp == NULL)
		{
			return NULL;
		}
		if(strcmp(temp->key, key) == 0)
		{
			return temp;
		}
		if(opt_yield & LOOKUP_YIELD)
		{
			sched_yield();
		}
		temp = temp->next;
		
	}
	return NULL;
}

int SortedList_length(SortedList_t *list)
{
	int i;
	int length = 0;
	for(i = 0; i < numLists; i++)
	{
		if(list == NULL)
		{
			return -1;
		}
		SortedListElement_t *temp = (list+i)->next;
		while(temp != (list + i))
		{
			if(temp->next->prev != temp->prev->next)
			{
				return -1;
			}
			length++;
			if(opt_yield & LOOKUP_YIELD)
			{
				sched_yield();
			}
			temp = temp ->next;
		}
	}
	return length;
}

