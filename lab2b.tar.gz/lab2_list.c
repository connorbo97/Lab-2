//NAME: Connor Borden
//EMAIL: connorbo97@g.ucla.edu
//ID: 004603469
#include <time.h>
#include <pthread.h>
#include <string.h>
#include <getopt.h>
#include <stdio.h>
#include <stdlib.h>
#include "SortedList.h"
#include <signal.h>

#define MAX_THREADS  24
#define MAX_ITERATIONS  100000
#define MAX_LISTS 24
int threadCount = 1;
int numIterations = 1;
int numLists=1;
int listFlag=0;
int opt_yield = 0;
int syncFlag = 0;
int mutexFlag = 0;
int spinFlag = 0;
char *testType = NULL;
char *yieldType = NULL;
char *syncType = NULL;
int spinLock[MAX_LISTS];
pthread_mutex_t locks[MAX_LISTS];
SortedListElement_t* elements;
SortedList_t* sharedList;
int cancelThreads = 0;
long long totalWaitTime = 0;
long totalLockCount = 0;
pthread_mutex_t WaitTimeLock;

long long counter = 0;


void exitFree(int sig)
{
	if(cancelThreads == 0)
	{
		if(testType != NULL)
			free(testType);
		if(yieldType != NULL)
			free(yieldType);
		if(syncType != NULL)
			free(syncType);
		if(sharedList != NULL)
			free(sharedList);
		if(elements != NULL)
			free(elements);
		cancelThreads = 1;
	}
	exit(sig);
}

void signalHandler(int signum)
{
	if(signum == SIGSEGV)
	{
		fprintf(stderr, "Segmentation fault encountered. Corrupted list.\n");
		cancelThreads =1;
		int retval = 2;
		pthread_exit(&retval);
	}
}
void handleOpt(int argc, char**	 argv)
{
	
	static struct option args[] =
	{
		{"threads", required_argument, 0, 't'},
		{"iterations", required_argument, 0, 'i'},
		{"yield", required_argument, 0, 'y'},
		{"sync", required_argument, 0, 's'},
		{"lists", required_argument, 0, 'l'},
		{0,0,0,0}	
	
	};
	int option;
	while((option = getopt_long(argc,argv, "t:i:y:s:l", args, NULL)) != -1)
	{
		switch(option)
		{
			case 't':
			//	printf("optarg%s\n", optarg);
				threadCount = atoi(optarg);
				break;
			case 'i':
			//	printf("optarg%s\n", optarg);
				numIterations = atoi(optarg);
				break;
			case 'y':
				
		//		printf("optarg%s\n", optarg);
				opt_yield=1;	
				if(strlen(optarg) > 0 || strlen(optarg) <=3)
				{
					strcpy(yieldType, optarg);
				}
				else
				{
					fprintf(stderr, "Only valid values for yield flag are i, d, l, id, dl, il,idl\n");
					exitFree(1);
				}
				break;
			case 's':
	//			printf("optarg%s\n", optarg);
				syncFlag = 1;
				if(strlen(optarg) == 1)
				{
					strcpy(syncType, optarg);

				}
				else
				{
					fprintf(stderr, "Only valid values for sync flag is m or s\n");
					exitFree(1);
				}
				break;	
			case 'l':
				//printf("optarg%s\n", optarg);
				listFlag = 1;
				numLists = atoi(optarg);
				if(numLists < 1 || numLists >= MAX_LISTS)
				{
					fprintf(stderr, "Number of lists must be 10 >= # of lists >= 1");
					exitFree(1);
				}
				break;
			default:
				fprintf(stderr, "--thread=# of threads wanted (default 1), --iterations=# of times each thread counts up and down, --yield makes threads yield and --sync=type of synchronization (either m or s)\n");
				exitFree(1);
		}
	}
}

int hash_function(const char* key)
{
	if(key == NULL)				//if empty key, just say it's in the 0 list
		return 0;
	int i;
	int total = 0;
	for(i =0; i < strlen(key); i++)
	{
		total += key[i];
	}
	int hash = total % numLists;
	return hash;
}

void*  threadFunction(void * threadNumber)
{
	long threadWaitTime = 0;
	long startTime;
	int tNum = *(int *)threadNumber;
	int i;
	long threadLockCount = 0;
	struct timespec time;
	for(i=0; i < numIterations && cancelThreads == 0; i++)
	{
		int val = tNum* numIterations + i;
		int hash = hash_function((elements + val)->key);
		if(mutexFlag)
		{
	//		printf("Trying to get lock %d in thread %d\n", hash, tNum);
			if ( clock_gettime( CLOCK_MONOTONIC, &time ) != 0 )
    			{
      				fprintf(stderr, "Could not get start time");
				exitFree(1);
    			}
			startTime = time.tv_nsec;
			pthread_mutex_lock(&(locks[hash]));
			if ( clock_gettime( CLOCK_MONOTONIC, &time ) != 0 )
    			{
      				fprintf(stderr, "Could not get start time");
				exitFree(1);
    			}
			if(time.tv_nsec > startTime)
				threadWaitTime += (time.tv_nsec - startTime);
			else
			{
			//	totalTime = (2147483647 - startTime) +   endTime;
				threadWaitTime += (999999999  - startTime) + time.tv_nsec;
			}
			threadLockCount++;
	//		printf("Got lock %d in thread %d\n", hash, tNum);
			SortedList_insert(sharedList + hash, elements + val);
	//		printf("Releasing lock %d in thread %d\n", hash, tNum);
			pthread_mutex_unlock(&(locks[hash]));
	//		printf("Released lock %d in thread %d\n", hash, tNum);
		}
		else if(spinFlag)
		{
			if ( clock_gettime( CLOCK_MONOTONIC, &time ) != 0 )
    			{
      				fprintf(stderr, "Could not get start time");
				exitFree(1);
    			}
			startTime = time.tv_nsec;
			while(__sync_lock_test_and_set(&spinLock[hash], 1));
			if ( clock_gettime( CLOCK_MONOTONIC, &time ) != 0 )
    			{
      				fprintf(stderr, "Could not get start time");
				exitFree(1);
    			}
			if(time.tv_nsec > startTime)
				threadWaitTime += (time.tv_nsec - startTime);
			else
			{
			//	totalTime = (2147483647 - startTime) +   endTime;
				threadWaitTime += (999999999  - startTime) + time.tv_nsec;
			}
			threadLockCount++;
			SortedList_insert(sharedList + hash, elements + val);
			__sync_lock_release(&spinLock[hash]);	
		}
		else
		{
			SortedList_insert(sharedList + hash, elements + val);
			
		}
	}
	int length;
	if(mutexFlag)
	{
		int i;
		for(i = 0; i < numLists; i++)
		{
	//		printf("GETTING ALL LOCKS:trying lock %d in thread %d\n", i, tNum);
			if ( clock_gettime( CLOCK_MONOTONIC, &time ) != 0 )
    			{
      				fprintf(stderr, "Could not get start time");
				exitFree(1);
    			}
			startTime = time.tv_nsec;
			pthread_mutex_lock(&(locks[i]));
			if ( clock_gettime( CLOCK_MONOTONIC, &time ) != 0 )
    			{
      				fprintf(stderr, "Could not get start time");
				exitFree(1);
    			}
			if(time.tv_nsec > startTime)
				threadWaitTime += (time.tv_nsec - startTime);
			else
			{
			//	totalTime = (2147483647 - startTime) +   endTime;
				threadWaitTime += (999999999  - startTime) + time.tv_nsec;
			}
			threadLockCount++;
	//		printf("Got lock %d in thread %d\n", i, tNum);
		}
	//	printf("Got all locks in thread %d\n",  tNum);

		length = SortedList_length(sharedList);
		for(i = 0; i < numLists; i++)
		{
	//		printf("Releasing lock %d in thread %d\n", i, tNum);
			pthread_mutex_unlock(&(locks[i]));
	//		printf("Released lock %d in thread %d\n", i, tNum);
		}
	}
	else if(spinFlag)
	{
		
		int i;
		for(i = 0; i < numLists; i++)
		{
			if ( clock_gettime( CLOCK_MONOTONIC, &time ) != 0 )
    			{
      				fprintf(stderr, "Could not get start time");
				exitFree(1);
    			}
			startTime = time.tv_nsec;
			while(__sync_lock_test_and_set(&spinLock[i], 1));
			if ( clock_gettime( CLOCK_MONOTONIC, &time ) != 0 )
    			{
      				fprintf(stderr, "Could not get start time");
				exitFree(1);
    			}
			if(time.tv_nsec > startTime)
				threadWaitTime += (time.tv_nsec - startTime);
			else
			{
			//	totalTime = (2147483647 - startTime) +   endTime;
				threadWaitTime += (999999999  - startTime) + time.tv_nsec;
			}
			threadLockCount++;
		}
		length = SortedList_length(sharedList);
		for(i = 0; i < numLists; i++)
		{
			__sync_lock_release(&spinLock[i]);	
		}
	}
	else
	{
		length = SortedList_length(sharedList);
		
	}
	if(length == -1 && cancelThreads == 0)
	{
		fprintf(stderr, "Obtained faulty list length. Corrupted list.\n");
		exitFree(2);
		cancelThreads = 1;
		
	}
	for(i=0; i < numIterations && cancelThreads == 0; i++)
	{
		int val = tNum* numIterations + i;
		int hash = hash_function((elements + val)->key);
		SortedListElement_t* found;
		if(mutexFlag)
		{
			if ( clock_gettime( CLOCK_MONOTONIC, &time ) != 0 )
    			{
      				fprintf(stderr, "Could not get start time");
				exitFree(1);
    			}
			startTime = time.tv_nsec;
			pthread_mutex_lock(&(locks[hash]));
			if ( clock_gettime( CLOCK_MONOTONIC, &time ) != 0 )
    			{
      				fprintf(stderr, "Could not get start time");
				exitFree(1);
    			}
			if(time.tv_nsec > startTime)
				threadWaitTime += (time.tv_nsec - startTime);
			else
			{
			//	totalTime = (2147483647 - startTime) +   endTime;
				threadWaitTime += (999999999  - startTime) + time.tv_nsec;
			}
			threadLockCount++;
			found = SortedList_lookup(sharedList + hash, elements[val].key);
			pthread_mutex_unlock(&(locks[hash]));
		}
		else if(spinFlag)
		{
			if ( clock_gettime( CLOCK_MONOTONIC, &time ) != 0 )
    			{
      				fprintf(stderr, "Could not get start time");
				exitFree(1);
    			}
			startTime = time.tv_nsec;
			while(__sync_lock_test_and_set(&spinLock[hash], 1));
			if ( clock_gettime( CLOCK_MONOTONIC, &time ) != 0 )
    			{
      				fprintf(stderr, "Could not get start time");
				exitFree(1);
    			}
			if(time.tv_nsec > startTime)
				threadWaitTime += (time.tv_nsec - startTime);
			else
			{
			//	totalTime = (2147483647 - startTime) +   endTime;
				threadWaitTime += (999999999  - startTime) + time.tv_nsec;
			}
			threadLockCount++;
			found = SortedList_lookup(sharedList + hash, elements[val].key);
			__sync_lock_release(&spinLock[hash]);	
		}
		else
		{
			found = SortedList_lookup(sharedList + hash, elements[val].key);
			
		}
		if(found == NULL && cancelThreads == 0)
		{	
			fprintf(stderr, "Could not find already inserted node. Corrupted list.\n");
			exitFree(2);
			cancelThreads = 1;
		}
		else
		{
			int retval = 0;
			if(mutexFlag)
			{
				if ( clock_gettime( CLOCK_MONOTONIC, &time ) != 0 )
    				{
      					fprintf(stderr, "Could not get start time");
					exitFree(1);
    				}
				startTime = time.tv_nsec;
				pthread_mutex_lock(&(locks[hash]));
				if ( clock_gettime( CLOCK_MONOTONIC, &time ) != 0 )
    				{
      					fprintf(stderr, "Could not get start time");
					exitFree(1);
    				}
				if(time.tv_nsec > startTime)
					threadWaitTime += (time.tv_nsec - startTime);
				else
				{
				//	totalTime = (2147483647 - startTime) +   endTime;
					threadWaitTime += (999999999  - startTime) + time.tv_nsec;
				}
				threadLockCount++;
				retval = SortedList_delete(found);
				pthread_mutex_unlock(&(locks[hash]));
			}
			else if(spinFlag)
			{
				if ( clock_gettime( CLOCK_MONOTONIC, &time ) != 0 )
    				{
      					fprintf(stderr, "Could not get start time");
					exitFree(1);
    				}
				startTime = time.tv_nsec;
				while(__sync_lock_test_and_set(&spinLock[hash], 1));
				if ( clock_gettime( CLOCK_MONOTONIC, &time ) != 0 )
    				{
      					fprintf(stderr, "Could not get start time");
					exitFree(1);
    				}
				if(time.tv_nsec > startTime)
					threadWaitTime += (time.tv_nsec - startTime);
				else
				{
				//	totalTime = (2147483647 - startTime) +   endTime;
					threadWaitTime += (999999999  - startTime) + time.tv_nsec;
				}
				threadLockCount++;
				retval = SortedList_delete(found);
				__sync_lock_release(&spinLock[hash]);	
			}
			else
			{
				retval = SortedList_delete(found);
				
			}
			if(retval == 1 && cancelThreads == 0)
			{
				fprintf(stderr, "Failed to delete a node despite inserting it. Corrupted list.\n");
				exitFree(2);
				cancelThreads=1;
			}
		}
	}
	if(cancelThreads == 1)
	{
		exitFree(2);	
	}
	
	pthread_mutex_lock(&WaitTimeLock);
	totalWaitTime += threadWaitTime;
	totalLockCount += threadLockCount;
	pthread_mutex_unlock(&WaitTimeLock);
	int retval = 0;
	pthread_exit(&retval);
}

void handleFlags()
{
	if(opt_yield)
	{
		if(strcmp(yieldType,"i") == 0)
		{
			strcpy(testType, "list-i-");
			opt_yield |= INSERT_YIELD;	
		}
		else if(strcmp(yieldType,"d") == 0)

		{
			strcpy(testType, "list-d-");
			opt_yield |= DELETE_YIELD;
		}
		else if(strcmp(yieldType,"l") == 0)
		{
			strcpy(testType, "list-l-");
			opt_yield |= LOOKUP_YIELD;
		}
		else if(strcmp(yieldType,"id") == 0)
		{
			strcpy(testType, "list-id-");
			opt_yield |= INSERT_YIELD;	
			opt_yield |= DELETE_YIELD;
			
		}
		else if(strcmp(yieldType,"il") == 0)
		{
			strcpy(testType, "list-il-");
			opt_yield |= INSERT_YIELD;	
			opt_yield |= LOOKUP_YIELD;
			
		}
		else if(strcmp(yieldType,"dl") == 0)
		{
			strcpy(testType, "list-dl-");
			opt_yield |= DELETE_YIELD;
			opt_yield |= LOOKUP_YIELD;
			
		}
		else if(strcmp(yieldType,"idl") == 0)
		{
			strcpy(testType, "list-idl-");
			opt_yield |= INSERT_YIELD;	
			opt_yield |= DELETE_YIELD;
			opt_yield |= LOOKUP_YIELD;
		}
		else if(strcmp(yieldType, "none") == 0)
		{
			strcpy(testType, "list-none-");
			opt_yield = 0;
		}
		else
		{
			fprintf(stderr, "Only valid values for yield flag are i, d, l, id, dl, il,idl\n");
			exitFree(1);
		}
	}
	else
	{
		strcpy(testType, "list-none-");
	}
	if(syncFlag == 1)
	{
		if(strcmp(syncType,"m") == 0)
		{
			mutexFlag = 1;
			
			if (pthread_mutex_init(&WaitTimeLock, NULL) != 0)
    			{
	       		 	fprintf(stderr, "Failed to initialize wait time lock number \n");
	       			exitFree(1);
			}
			//add more locks
			int i;
			for(i = 0; i < numLists; i++)
			{
				if (pthread_mutex_init(&locks[i], NULL) != 0)
    				{
	       			 	fprintf(stderr, "Failed to initialize mutex number %d\n", i);
	       		 		exitFree(1);
    				}
				
			}

			strcat(testType, syncType);
		}
		else if(strcmp(syncType,"s") == 0)
		{
			spinFlag = 1;
			int i;
			for(i=0; i < numLists; i++)
				spinLock[i] = 0;
			strcat(testType, syncType);
		}
		else if(strcmp(syncType, "none") == 0) //do nothing
		{
			strcat(testType, syncType);
		}
		else
		{
			fprintf(stderr, "Only valid values for sync flag is m or s\n");
			exitFree(1);
		}
	}
	else
	{
		strcat(testType, "none");
	}

	if(listFlag == 1)
	{
		sharedList = malloc(numLists*sizeof(SortedList_t));
		if(sharedList == NULL)
		{
			fprintf(stderr, "Malloc failed to allocate data");
			exitFree(1);
		}
		int i;
		for(i=0; i < numLists; i++)
		{
			SortedList_t* temp = sharedList + i;
			temp->key = NULL;
			temp->next = temp;
			temp->prev = temp;
		}
	}
	else
	{
		sharedList = malloc(sizeof(SortedList_t));
		sharedList->key = NULL;
		sharedList->next = sharedList;
		sharedList->prev = sharedList;
		
	}
}

void createThreadElements()
{
	char* keyVal = NULL;
	char* temp = malloc(10*sizeof(char));
	if(temp == NULL)
	{
		fprintf(stderr, "Malloc failed to allocate data");
		exitFree(1);
	}
	int i, j;
	for(i = 0; i < threadCount; i++)
	{
		for(j = 0; j < numIterations; j++)
		{
			keyVal = malloc(10* sizeof(char));
			strcpy(keyVal, "");
			if(keyVal == NULL)
			{
				fprintf(stderr, "Malloc failed to allocate data");
				exitFree(1);
			}
			int k;
			for(k=0; k< 5; k++)
			{
				int randomNumber = rand() % 10;
				sprintf(temp, "%d", randomNumber);
				strcat(keyVal, temp);
			}
			sprintf(temp, "%d", i);
			strcat(keyVal, temp);
			elements[i*numIterations+j].key = keyVal;
		}
	}
}
int main(int argc, char** argv)
{
	srand(time(NULL));
	signal(SIGSEGV, signalHandler);
	testType = malloc(20);
	if(testType == NULL)
	{
		fprintf(stderr, "Malloc failed to allocate data");
		exitFree(1);
	}
	strcpy(testType, "list-");
	yieldType = malloc(5);
	if(yieldType == NULL)
	{
		fprintf(stderr, "Malloc failed to allocate data");
		exitFree(1);
	}
	strcpy(yieldType, "none");
	syncType = malloc (5);
	if(syncType == NULL)
	{
		fprintf(stderr, "Malloc failed to allocate data");
		exitFree(1);
	}
	strcpy(syncType, "none");

	handleOpt(argc, argv);
	
	handleFlags();

	elements = (SortedListElement_t*)malloc(threadCount*numIterations * sizeof(SortedListElement_t));
	
	createThreadElements();

	struct timespec time;
	struct timespec time2;	
	int i;
	//pthread_t *threads;
        //threads = malloc(sizeof(pthread_t) * threadCount);
        pthread_t threads[1000];
	pthread_attr_t attr;
	pthread_attr_init(&attr);
	time.tv_nsec = 0;
	time.tv_sec = 0;
	if ( clock_getres( CLOCK_MONOTONIC, &time ) != 0 )
    	{
      		fprintf(stderr, "Could not get resolution of clock");
		exitFree(1);
    	}
	if ( clock_gettime( CLOCK_MONOTONIC, &time ) != 0 )
    	{
      		fprintf(stderr, "Could not get start time");
		exitFree(1);
    	}
	
	long startTime = time.tv_nsec;
	int startSec = time.tv_sec;		
	for(i = 0; i < threadCount; i++)
	{
		int* arg = malloc(sizeof(*arg));
		if(arg == NULL)
		{
			fprintf(stderr, "Malloc failed to allocate memory");
			exitFree(1);
		}
		*arg = i;
		if(pthread_create(&threads[i], &attr, threadFunction, arg) != 0)
		{
			fprintf(stderr, "Failed to create thread %d\n", (i + 1));
			exitFree(1);
		}
	}
	
	for(i = 0; i < threadCount; i++)
	{
		int val = pthread_join(threads[i],NULL);
		if(val != 0)
		{
			fprintf(stderr, "Thread %d failed to join \n", (i + 1));
			exitFree(1);
		}	
	}
	if(cancelThreads == 1)
	{
		exitFree(2);
	}
	
	if ( clock_gettime( CLOCK_MONOTONIC, &time2 ) != 0 )
    	{
      		fprintf(stderr, "Could not get end time");
		exitFree(1);
    	}
	long endTime = time2.tv_nsec;
	long totalTime;
	int endSec = time2.tv_sec - startSec;
	if(endTime > startTime)
		totalTime = endTime - startTime;
	else
	{
	//	totalTime = (2147483647 - startTime) +   endTime;
		totalTime = (999999999  - startTime) + endTime;
		endSec = endSec +1 -1;		//to get rid of warning
	}
	/*
	int  j;
	for(i = 0; i < threadCount; i++)
	{
		for(j = 0;j < numIterations; j++)
		{
			printf("%s", elements[i*numIterations + j].key);
		} 
	}
	*/
	if(counter != -1)
	{
		counter = SortedList_length(sharedList);
		if(counter == -1)
		{
			fprintf(stderr, "Corrupted list");
			exitFree(2);
		}
	}
	if(syncFlag == 0)
		totalLockCount=1;
	////////////////printf("%ld\n%ld\n%ld\n%d\n", endTime, startTime, (endTime -  startTime), endSec);
	unsigned long totalOptsPerformed = threadCount * 3 * numIterations;
	unsigned long long  averageTimePerOp = totalTime/totalOptsPerformed;
	printf("%s,%d,%d,%d,%lu,%ld,%llu,%lld\n", testType, threadCount, numIterations, numLists, totalOptsPerformed, totalTime, averageTimePerOp, totalWaitTime/totalLockCount);
	exitFree(0);
//	free(threads);
	return 0;
}
