//NAME: Connor Borden
//EMAIL: connorbo97@g.ucla.edu
//ID: 004603469
#include <time.h>
#include <pthread.h>
#include <string.h>
#include <getopt.h>
#include <stdio.h>
#include <stdlib.h>

int threadCount = 1;
int numIterations = 1;
int yieldFlag = 0;
int syncFlag = 0;
int mutexFlag = 0;
int spinFlag = 0;
int compareFlag = 0;
char *testType = NULL;
char *syncType = NULL;
long long counter = 0;
pthread_mutex_t lock;
int spinLock = 0;
void add(long long *pointer, long long value)
{
	long long sum =*pointer + value;
	if(yieldFlag == 1)
	{
		sched_yield();
	}
	
	*pointer = sum;
}

void mutexAdd(long long *pointer, long long value)
{
	pthread_mutex_lock(&lock);	
	long long sum =*pointer + value;
	if(yieldFlag == 1)
	{
		sched_yield();
	}
	
	*pointer = sum;
	pthread_mutex_unlock(&lock);
}

void spinAdd(long long *pointer, long long value)
{
	while(__sync_lock_test_and_set(&spinLock, 1));
	long long sum =*pointer + value;
	if(yieldFlag == 1)
	{
		sched_yield();
	}
	
	*pointer = sum;
	__sync_lock_release(&spinLock);
}


void compareAndSwapAdd(long long *pointer, long long value)
{
	long long old;
	long long new;
	do	
	{
		old = *pointer;
		if(yieldFlag == 1)
		{	
			sched_yield();
		}
		new = old + value;
	}
	while(__sync_val_compare_and_swap(pointer, old, new) != old);
	
}

void exitFree(int sig)
{
	if(testType != NULL)
		free(testType);
	if(syncType != NULL)
		free(syncType);
	exit(sig);
}

void handleOpt(int argc, char** argv)
{
	
	static struct option args[] =
	{
		{"threads", required_argument, 0, 't'},
		{"iterations", required_argument, 0, 'i'},
		{"yield", no_argument, 0, 'y'},
		{"sync", required_argument, 0, 's'},
		{0,0,0,0}	
	
	};
	int option;
	while((option = getopt_long(argc,argv, "t:i:y:s", args, NULL)) != -1)
	{
		switch(option)
		{
			case 't':
				threadCount = atoi(optarg);
				break;
			case 'i':
				numIterations = atoi(optarg);
				break;
			case 'y':
				yieldFlag = 1;	
				break;
			case 's':
				syncFlag = 1;
	//			printf("%d, %s", strlen(optarg), optarg);
				if(strlen(optarg) == 1)
				{
					strcpy(syncType, optarg);
				}
				else
				{
					fprintf(stderr, "Only valid values for sync flag is m, s, or c\n");
					exitFree(1);
				}	
				break;
				
			default:
				fprintf(stderr, "--thread=# of threads wanted (default 1), --iterations=# of times each thread counts up and down, --yield makes threads yield, --sync=type of synchronization used (m, s, or c)\n");
				exitFree(1);
		}
	}
}

void*  threadFunction(void * dummy)
{
	int i = 0;
	for(i=0; i < numIterations; i++)
	{
		if(!syncFlag)
		{
			add(&counter, 1);
		}
		else
		{
			if(mutexFlag)
			{
				mutexAdd(&counter, 1);
			}
			else if(spinFlag)
			{
				spinAdd(&counter, 1);
			}
			else if(compareFlag)
			{
				compareAndSwapAdd(&counter, 1);
			}
			else
			{
				fprintf(stderr, "Incorrect sync flag");
				exitFree(1);
			}
		}
	}
	for(i=0; i < numIterations; i++)
	{
		if(!syncFlag)
		{
			add(&counter, -1);
		}
		else
		{
			if(mutexFlag)
			{
				mutexAdd(&counter, -1);
			}
			else if(spinFlag)
			{
				spinAdd(&counter, -1);
			}
			else if(compareFlag)
			{
				compareAndSwapAdd(&counter, -1);
			}
			else
			{
				fprintf(stderr, "Incorrect sync flag");
				exitFree(1);
			}
		}
	} 
	pthread_exit(0);
}

void handleSyncFlag()
{
	if(yieldFlag)
	{
		strcpy(testType, "add-yield-");
	}
	strcat(testType, syncType);
	if(strcmp(syncType,"m") == 0)
	{
		mutexFlag = 1;
		if (pthread_mutex_init(&lock, NULL) != 0)
    		{
	        	fprintf(stderr, "Failed to initialize mutex\n");
	        	exitFree(1);
    		}
	}
	else if(strcmp(syncType,"s") == 0)
	{
		spinFlag = 1;
	}
	else if(strcmp(syncType,"c") == 0)
	{
		compareFlag = 1;
	}
	else if(strcmp(syncType, "none") == 0){} //do nothing
	else
	{
		fprintf(stderr, "Only valid values for sync flag is m, s, or c\n");
		exitFree(1);
	}
}
int main(int argc, char** argv)
{
	testType = malloc(15);
	strcpy(testType, "add-");
	syncType = malloc(5);
	strcpy(syncType, "none");
	
	handleOpt(argc, argv);
	
	handleSyncFlag();

	
	struct timespec time;
	
	int i;
	//pthread_t *threads;
        //threads = malloc(sizeof(pthread_t) * threadCount);
        pthread_t threads[1000];
	pthread_attr_t attr;
	pthread_attr_init(&attr);
	if ( clock_getres( CLOCK_MONOTONIC, &time ) != 0 )
    	{
      		fprintf(stderr, "Could not get resolution of clock");
		exitFree(1);
    	}
	if ( clock_gettime( CLOCK_MONOTONIC, &time ) != 0 )
    	{
      		fprintf(stderr, "Could not get start time");
		exitFree(1);
    	}
	
	unsigned long startTime = time.tv_nsec;		
	for(i = 0; i < threadCount; i++)
	{
		if(pthread_create(&threads[i], &attr, threadFunction, NULL) != 0)
		{
			fprintf(stderr, "Failed to create thread %d\n", (i + 1));
			exitFree(1);
		}
	}
	
	for(i = 0; i < threadCount; i++)
	{
		int val = pthread_join(threads[i],NULL);
		if(val != 0)
		{
			fprintf(stderr, "Thread %d failed to join \n", (i + 1));
			exitFree(1);
		}	
	}
	if ( clock_gettime( CLOCK_MONOTONIC, &time ) != 0 )
    	{
      		fprintf(stderr, "Could not get end time");
		exitFree(1);
    	}
	
	unsigned long long totalTime = time.tv_nsec - startTime;
	unsigned long totalOptsPerformed = threadCount * 2 * numIterations;
	unsigned long long  averageTimePerOp = totalTime/totalOptsPerformed;
	printf("%s,%d,%d,%lu,%llu,%llu,%lld\n", testType, threadCount, numIterations, totalOptsPerformed, totalTime, averageTimePerOp, counter);
	exitFree(0);
//	free(threads);
	return 0;
}
