//NAME: Connor Borden
//EMAIL: connorbo9&@g.ucla.edu
//ID: 004603469
#include <time.h>
#include <pthread.h>
#include <string.h>
#include <getopt.h>
#include <stdio.h>
#include <stdlib.h>
#include "SortedList.h"


extern int mutexFlag;
extern int spinFlag;
extern int spinLock;

void SortedList_insert(SortedList_t *list, SortedListElement_t *element)
{
	if(list == NULL || element == NULL)
	{
		return;
	}
	SortedListElement_t *temp = list->next; //not the header
	
	//else if(mutexFlag)
	//	pthread_mutex_lock(&lock);
		if(temp == NULL)
		{
			return;
		}
	
	while(temp != list)
	{
		if(strcmp(element->key, temp->key) <= 0)
		{
			break;
		}
		
		if(temp->next == NULL)
		{
			return;
		}
		temp = temp->next;
	}
	
	if(opt_yield & INSERT_YIELD)
	{
		sched_yield();
	}
	if(temp->prev == NULL)
	{
		return;
	}
	element->next = temp;
	element->prev = temp->prev;
	temp->prev->next = element;
	temp->prev = element;

}

int SortedList_delete(SortedListElement_t *element)
{
	if(element == NULL)
	{
		return 1;
	}
	if(element->next == NULL || element->prev == NULL || element->next->prev == NULL || element->prev->next == NULL)
	{
		return 1;
	}
	if(element->next->prev == element->prev->next)
	{
		if(opt_yield & DELETE_YIELD)
			sched_yield();
		
		element->prev->next = element->next;
		element->next->prev = element->prev;
		element->next = NULL;
		element->prev = NULL;
		return 0;
	}
	else
	{
		return 1; //means corrupted pointers
	}
}

SortedListElement_t *SortedList_lookup(SortedList_t *list, const char *key)
{
	int count =0;
	if(list == NULL || key == NULL)
	{	
		return NULL;
	}
	if(SortedList_length(list) <= 0)
	{
		return NULL;
	}
	SortedListElement_t *temp = list->next; //first non head
	if(temp == NULL)
	{
		return NULL;
	}
	while(temp != list )
	{
		count++;
		if(temp == NULL)
		{
			return NULL;
		}
		if(strcmp(temp->key, key) == 0)
		{
			return temp;
		}
		if(opt_yield & LOOKUP_YIELD)
		{
			sched_yield();
		}
		temp = temp->next;
		
	}
	return NULL;
}

int SortedList_length(SortedList_t *list)
{
	int length = 0;
	SortedListElement_t *temp = list->next;
	if(list == NULL)
	{
		return -1;
	}
	if(temp == NULL)
	{
		return -1;
	}
	while(temp != list)
	{
		if(temp->next == NULL || temp->prev == NULL || temp->next->prev == NULL || temp->prev->next == NULL)
		{
			return -1;
		}
		if(temp->next->prev != temp->prev->next)
		{
			return -1;
		}
		length++;
		if(temp->next == NULL)
		{
			return -1;
		}
		temp = temp ->next;
	}
	return length;
}

