//NAME: Connor Borden
//EMAIL: connorbo97@g.ucla.edu
//ID: 004603469
#include <time.h>
#include <pthread.h>
#include <string.h>
#include <getopt.h>
#include <stdio.h>
#include <stdlib.h>
#include "SortedList.h"
#include <signal.h>

#define MAX_THREADS  24
#define MAX_ITERATIONS  100000
int threadCount = 1;
int numIterations = 1;
int opt_yield = 0;
int syncFlag = 0;
int mutexFlag = 0;
int spinFlag = 0;
char *testType = NULL;
char *yieldType = NULL;
char *syncType = NULL;
int spinLock = 0;
pthread_mutex_t lock;
SortedListElement_t* elements;
SortedList_t* sharedList;
int cancelThreads = 0;

long long counter = 0;


void exitFree(int sig)
{
	if(testType != NULL)
		free(testType);
	if(yieldType != NULL)
		free(yieldType);
	if(syncType != NULL)
		free(syncType);
	if(sharedList != NULL)
		free(sharedList);
	if(elements != NULL)
		free(elements);
	exit(sig);
}

void signalHandler(int signum)
{
	if(signum == SIGSEGV)
	{
		fprintf(stderr, "Segmentation fault encountered. Corrupted list.\n");
		cancelThreads =1;
		int retval = 2;
		pthread_exit(&retval);
	}
}
void handleOpt(int argc, char**	 argv)
{
	
	static struct option args[] =
	{
		{"threads", required_argument, 0, 't'},
		{"iterations", required_argument, 0, 'i'},
		{"yield", required_argument, 0, 'y'},
		{"sync", required_argument, 0, 's'},
		{0,0,0,0}	
	
	};
	int option;
	while((option = getopt_long(argc,argv, "t:i:y", args, NULL)) != -1)
	{
		switch(option)
		{
			case 't':
				threadCount = atoi(optarg);
				break;
			case 'i':
				numIterations = atoi(optarg);
				break;
			case 'y':
				
				opt_yield=1;	
				if(strlen(optarg) > 0 || strlen(optarg) <=3)
				{
					strcpy(yieldType, optarg);
				}
				else
				{
					fprintf(stderr, "Only valid values for yield flag are i, d, l, id, dl, il,idl\n");
					exitFree(1);
				}
				break;
			case 's':
				syncFlag = 1;
				if(strlen(optarg) == 1)
				{
					strcpy(syncType, optarg);

				}
				else
				{
					fprintf(stderr, "Only valid values for sync flag is m or s\n");
					exitFree(1);
				}
				break;	
			default:
				fprintf(stderr, "--thread=# of threads wanted (default 1), --iterations=# of times each thread counts up and down, --yield makes threads yield and --sync=type of synchronization (either m or s)\n");
				exitFree(1);
		}
	}
}

void*  threadFunction(void * threadNumber)
{
	int tNum = *(int *)threadNumber;
	int i;
	for(i=0; i < numIterations && cancelThreads == 0; i++)
	{
		int val = tNum* numIterations + i;
		if(mutexFlag)
		{
			pthread_mutex_lock(&lock);
			SortedList_insert(sharedList, elements + val);
			pthread_mutex_unlock(&lock);
		}
		else if(spinFlag)
		{
			while(__sync_lock_test_and_set(&spinLock, 1));
			SortedList_insert(sharedList, elements + val);
			__sync_lock_release(&spinLock);	
		}
		else
		{
			SortedList_insert(sharedList, elements + val);
			
		}
	}
	if(mutexFlag)
	{
		pthread_mutex_lock(&lock);
		pthread_mutex_unlock(&lock);
	}
	else if(spinFlag)
	{
		while(__sync_lock_test_and_set(&spinLock, 1));
		SortedList_length(sharedList);
		__sync_lock_release(&spinLock);	
	}
	else
	{
		SortedList_length(sharedList);
		
	}
	for(i=0; i < numIterations && cancelThreads == 0; i++)
	{
		int val = tNum* numIterations + i;
		SortedListElement_t* found;
		if(mutexFlag)
		{
			pthread_mutex_lock(&lock);
			found = SortedList_lookup(sharedList, elements[val].key);
			pthread_mutex_unlock(&lock);
		}
		else if(spinFlag)
		{
			while(__sync_lock_test_and_set(&spinLock, 1));
			found = SortedList_lookup(sharedList, elements[val].key);
			__sync_lock_release(&spinLock);	
		}
		else
		{
			found = SortedList_lookup(sharedList, elements[val].key);
			
		}
		if(found == NULL && cancelThreads == 0)
		{	
			fprintf(stderr, "Could not find already inserted node. Corrupted list.\n");
			cancelThreads = 1;
			int retval = 1;
			pthread_exit(&retval);
		}
		else
		{
			int retval = 0;
			if(mutexFlag)
			{
				pthread_mutex_lock(&lock);
				retval = SortedList_delete(found);
				pthread_mutex_unlock(&lock);
			}
			else if(spinFlag)
			{
				while(__sync_lock_test_and_set(&spinLock, 1));
				retval = SortedList_delete(found);
				__sync_lock_release(&spinLock);	
			}
			else
			{
				retval = SortedList_delete(found);
				
			}
			if(retval == 1 && cancelThreads == 0)
			{
				fprintf(stderr, "Failed to delete a node despite inserting it. Corrupted list.\n");
				exitFree(1);
				cancelThreads = 1;
				pthread_exit(&retval);
			}
		}
	}
	if(cancelThreads == 1)
	{
		int retval = 2;
		pthread_exit(&retval);
	}
	int retval = 0;
	pthread_exit(&retval);
}

void handleFlags()
{
	if(opt_yield)
	{
		if(strcmp(yieldType,"i") == 0)
		{
			strcpy(testType, "list-i-");
			opt_yield |= INSERT_YIELD;	
		}
		else if(strcmp(yieldType,"d") == 0)
		{
			strcpy(testType, "list-d-");
			opt_yield |= DELETE_YIELD;
		}
		else if(strcmp(yieldType,"l") == 0)
		{
			strcpy(testType, "list-l-");
			opt_yield |= LOOKUP_YIELD;
		}
		else if(strcmp(yieldType,"id") == 0)
		{
			strcpy(testType, "list-id-");
			opt_yield |= INSERT_YIELD;	
			opt_yield |= DELETE_YIELD;
			
		}
		else if(strcmp(yieldType,"il") == 0)
		{
			strcpy(testType, "list-il-");
			opt_yield |= INSERT_YIELD;	
			opt_yield |= LOOKUP_YIELD;
			
		}
		else if(strcmp(yieldType,"dl") == 0)
		{
			strcpy(testType, "list-dl-");
			opt_yield |= DELETE_YIELD;
			opt_yield |= LOOKUP_YIELD;
			
		}
		else if(strcmp(yieldType,"idl") == 0)
		{
			strcpy(testType, "list-idl-");
			opt_yield |= INSERT_YIELD;	
			opt_yield |= DELETE_YIELD;
			opt_yield |= LOOKUP_YIELD;
		}
		else if(strcmp(yieldType, "none") == 0)
		{
			strcpy(testType, "list-none-");
			opt_yield = 0;
		}
		else
		{
			fprintf(stderr, "Only valid values for yield flag are i, d, l, id, dl, il,idl\n");
			exitFree(1);
		}
	}
	else
	{
		strcpy(testType, "list-none-");
	}
	if(syncFlag == 1)
	{
		if(strcmp(syncType,"m") == 0)
		{
			mutexFlag = 1;
			//add more locks
			if (pthread_mutex_init(&lock, NULL) != 0)
    			{
	       		 	fprintf(stderr, "Failed to initialize mutex\n");
	       	 		exitFree(1);
    			}
			strcat(testType, syncType);
		}
		else if(strcmp(syncType,"s") == 0)
		{
			spinFlag = 1;
			strcat(testType, syncType);
		}
		else if(strcmp(syncType, "none") == 0) //do nothing
		{
			strcat(testType, syncType);
		}
		else
		{
			fprintf(stderr, "Only valid values for sync flag is m or s\n");
			exitFree(1);
		}
	}
	else
	{
		strcat(testType, "none");
	}
}

void createThreadElements()
{
	char* keyVal = NULL;
	char* temp = malloc(10*sizeof(char));
	if(temp == NULL)
	{
		fprintf(stderr, "Malloc failed to allocate data");
		exitFree(1);
	}
	int i, j;
	for(i = 0; i < threadCount; i++)
	{
		for(j = 0; j < numIterations; j++)
		{
			keyVal = malloc(10* sizeof(char));
			if(keyVal == NULL)
			{
				fprintf(stderr, "Malloc failed to allocate data");
				exitFree(1);
			}
			sprintf(temp, "%d", i);
			strcpy(keyVal, temp);
			strcat(keyVal, "_");
			sprintf(temp, "%d", j);
			strcat(keyVal, temp);
			elements[i*numIterations+j].key = keyVal;
		}
	}
}
int main(int argc, char** argv)
{
	signal(SIGSEGV, signalHandler);
	testType = malloc(20);
	if(testType == NULL)
	{
		fprintf(stderr, "Malloc failed to allocate data");
		exitFree(1);
	}
	strcpy(testType, "list-");
	yieldType = malloc(5);
	if(yieldType == NULL)
	{
		fprintf(stderr, "Malloc failed to allocate data");
		exitFree(1);
	}
	strcpy(yieldType, "none");
	syncType = malloc (5);
	if(syncType == NULL)
	{
		fprintf(stderr, "Malloc failed to allocate data");
		exitFree(1);
	}
	strcpy(syncType, "none");

	handleOpt(argc, argv);
	
	handleFlags();

	elements = (SortedListElement_t*)malloc(threadCount*numIterations * sizeof(SortedListElement_t));
	
	createThreadElements();
	sharedList = malloc(sizeof(SortedList_t));
	if(sharedList == NULL)
	{
		fprintf(stderr, "Malloc failed to allocate data");
		exitFree(1);
	}
	sharedList->key = NULL;
	sharedList->next = sharedList;
	sharedList->prev = sharedList;

	struct timespec time;
	
	int i;
	//pthread_t *threads;
        //threads = malloc(sizeof(pthread_t) * threadCount);
        pthread_t threads[1000];
	pthread_attr_t attr;
	pthread_attr_init(&attr);
	if ( clock_getres( CLOCK_MONOTONIC, &time ) != 0 )
    	{
      		fprintf(stderr, "Could not get resolution of clock");
		exitFree(1);
    	}
	if ( clock_gettime( CLOCK_MONOTONIC, &time ) != 0 )
    	{
      		fprintf(stderr, "Could not get start time");
		exitFree(1);
    	}
	
	unsigned long startTime = time.tv_nsec;		
	for(i = 0; i < threadCount; i++)
	{
		int* arg = malloc(sizeof(*arg));
		if(arg == NULL)
		{
			fprintf(stderr, "Malloc failed to allocate memory");
			exitFree(1);
		}
		*arg = i;
		if(pthread_create(&threads[i], &attr, threadFunction, arg) != 0)
		{
			fprintf(stderr, "Failed to create thread %d\n", (i + 1));
			exitFree(1);
		}
	}
	
	for(i = 0; i < threadCount; i++)
	{
		int val = pthread_join(threads[i],NULL);
		if(val != 0)
		{
			fprintf(stderr, "Thread %d failed to join \n", (i + 1));
			exitFree(1);
		}	
	}
	if(cancelThreads == 1)
	{
		exitFree(2);
	}
	
	if ( clock_gettime( CLOCK_MONOTONIC, &time ) != 0 )
    	{
      		fprintf(stderr, "Could not get end time");
		exitFree(1);
    	}
	unsigned long long totalTime = time.tv_nsec - startTime;
/*	int  j;
	for(i = 0; i < threadCount; i++)
	{
		for(j = 0;j < numIterations; j++)
		{
			printf("%s", elements[i*numIterations + j].key);
		} 
	}*/
	if(counter != -1)
	{
		counter = SortedList_length(sharedList);
		if(counter == -1)
		{
			fprintf(stderr, "Corrupted list");
			exitFree(2);
		}
	}
	unsigned long totalOptsPerformed = threadCount * 3 * numIterations;
	unsigned long long  averageTimePerOp = totalTime/totalOptsPerformed;
	printf("%s,%d,%d,%d,%lu,%llu,%llu\n", testType, threadCount, numIterations, 1, totalOptsPerformed, totalTime, averageTimePerOp);
	exitFree(0);
//	free(threads);
	return 0;
}
